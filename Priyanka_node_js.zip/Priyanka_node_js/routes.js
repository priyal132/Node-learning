const express = require("express");
const mongoose = require("mongoose");
const user = require("./models");
const bcrypt = require("bcrypt");
const router = express.Router()

router.post('/signup', function(request,response, next)
{
    user.save({
	email: request.body.email,
	password: request.body.password
		})
		
		.then(result=>{
			console.log('then result console')
			console.log(result)
			return response.status(200).json(result)
		})
		.catch(error=>{
			console.log(error)
			return response.status(500).json({error})
		})
})


	
	module.exports = router